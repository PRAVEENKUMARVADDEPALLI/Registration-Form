// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-sign-up',
//   templateUrl: './sign-up.component.html',
//   styleUrls: ['./sign-up.component.css']
// })
// export class SignUpComponent implements OnInit {

//   constructor() { }

//   ngOnInit(): void {
//   }

// }


import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
//import * as constants from '../../core/general-config';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  public signUp: FormGroup;
  public confirmPasswordErrorMsg: boolean = false;

  constructor() {
    this.signUp = new FormGroup({});
  }

  ngOnInit(): void {
    this.createSignUpForm();
  }
  /*
   * @description - Touches all Inputs to ensurer any Input may not have been touched
   * @returns {void} - Return as void
   */
  private touchFormControls(): void {
    Object.keys(this.signUp.controls).forEach(field => {
      this.signUp.get(field)?.markAsTouched({onlySelf:true});
    });
  }


  private createSignUpForm(): void {
    this.signUp = new FormGroup({
      FirstName : new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(16)]),
      LastName : new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(16)]),
      Email : new FormControl('', [Validators.required, Validators.pattern(/^(([^<>()\[\]\\.,,:\s@"]+(\.[^<>()\[\]\\.,,:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]),
      PhoneNumber:new FormControl('', [Validators.required, Validators.pattern('[789][0-9]{9}')]),
      Password : new FormControl('', [Validators.required]),
      ConfirmPassword : new FormControl('', [Validators.required])
    });

    this.signUp.valueChanges.subscribe(values => {
      if (values && values.Password && values.ConfirmPassword && values.Password !== values.ConfirmPassword) {
        this.confirmPasswordErrorMsg = true;
      } else {
        this.confirmPasswordErrorMsg = false;
      }
    });
  }

  public register(): void {
    this.touchFormControls();
    if (this.signUp.invalid) {
      return;
    }
    if (this.confirmPasswordErrorMsg) {
      return;
    }  
    console.log(this.signUp.value);
  }

}
